package com.example.demo.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Books;


public interface BooksRepository extends CrudRepository<Books, Integer> {

}
