package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Books;
import com.example.demo.service.BooksService;

@RestController						//Create this class as Controller for the spring
public class BooksController {

	@Autowired						//Autowiring the BookService class.
	BooksService booksService;

	@GetMapping("/book")			// /book URL is used for call or access this function
	private List<Books> getAllBooks() {
		return booksService.getAllBooks();
	}

	@GetMapping("/book/{bookid}")
	private Books getBooks(@PathVariable("bookid") int bookid) {		//PathVariable means here this bookid required to call this method.
		return booksService.getBooksById(bookid);
	}

	@DeleteMapping("/book/{bookid}")
	private void deleteBook(@PathVariable("bookid") int bookid) {
		booksService.delete(bookid);
	}

	@PostMapping("/books")
	private int saveBook(@RequestBody Books books) {	//Requesting the service to post/save data.
		booksService.saveOrUpdate(books);
		return books.getBookid();
	}

	@PutMapping("/books")								//Put is used for update the things.
	private Books update(@RequestBody Books books) {
		booksService.saveOrUpdate(books);
		return books;
	}
}
